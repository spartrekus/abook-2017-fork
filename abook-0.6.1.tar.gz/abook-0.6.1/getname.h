#ifndef _GETNAME_H
#define _GETNAME_H

void getname(char *, char **, char **);
#if 0
char *spamify(char *input);
#endif

#endif
