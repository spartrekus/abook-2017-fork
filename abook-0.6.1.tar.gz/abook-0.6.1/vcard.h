#ifndef _VCARD_H
#define _VCARD_H

#include <vf_iface.h>

int vcard_parse_file_libvformat(char *filename);

#endif
